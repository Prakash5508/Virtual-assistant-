import pip
pip.main(['install','handwrite'])


